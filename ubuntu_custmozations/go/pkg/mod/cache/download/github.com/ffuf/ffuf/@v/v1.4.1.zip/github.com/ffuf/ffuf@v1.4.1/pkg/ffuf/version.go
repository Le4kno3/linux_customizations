package ffuf

var (
	//VERSION holds the current version number
	VERSION = "1.4.1"
	//VERSION_APPENDIX holds additional version definition
	VERSION_APPENDIX = "-dev"
)
