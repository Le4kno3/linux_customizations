window.n = 0

window.count = () => {
  return window.n++
}
