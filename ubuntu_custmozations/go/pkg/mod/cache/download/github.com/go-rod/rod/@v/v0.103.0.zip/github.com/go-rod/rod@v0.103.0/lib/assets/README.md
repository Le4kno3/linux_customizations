# Asserts

Static files for the project
