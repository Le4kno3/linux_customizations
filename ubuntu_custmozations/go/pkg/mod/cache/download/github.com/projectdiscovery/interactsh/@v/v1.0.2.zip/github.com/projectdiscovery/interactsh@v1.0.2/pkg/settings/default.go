package settings

const (
	CorrelationIdLengthDefault      = 20
	CorrelationIdNonceLengthDefault = 13
)
