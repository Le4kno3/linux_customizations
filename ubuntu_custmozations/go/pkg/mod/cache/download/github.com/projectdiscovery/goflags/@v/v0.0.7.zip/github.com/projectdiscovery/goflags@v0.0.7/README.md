# goflags

A wrapper on go `flag` library adding some convenience wrappers like better Usage, short and long flags, config file support, etc.

### Thanks

1. spf13/cobra - The very nice usage template for the command line.