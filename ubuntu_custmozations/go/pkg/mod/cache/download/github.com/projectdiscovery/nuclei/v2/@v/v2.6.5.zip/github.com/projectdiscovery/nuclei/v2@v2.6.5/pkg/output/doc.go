// Package output implements output writing interfaces for nuclei.
package output
