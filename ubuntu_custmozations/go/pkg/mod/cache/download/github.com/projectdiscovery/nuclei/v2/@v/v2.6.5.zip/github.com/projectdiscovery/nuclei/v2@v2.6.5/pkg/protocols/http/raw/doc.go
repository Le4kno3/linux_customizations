// Package raw provides raw http request parsing abilities for nuclei.
package raw
