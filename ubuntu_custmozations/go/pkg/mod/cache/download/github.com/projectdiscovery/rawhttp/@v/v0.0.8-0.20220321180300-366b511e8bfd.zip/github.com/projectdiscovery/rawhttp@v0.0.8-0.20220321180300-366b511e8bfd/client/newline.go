package client

const NewLine = "\r\n"
